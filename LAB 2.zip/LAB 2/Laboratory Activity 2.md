Laboratory Activity 2: Working with HTTP actions and API parameters

It uses a tool called FastAPI to make it work on the web.

First, it sets up the basic tools it needs, like how to handle web requests and how to organize the to-do list items.

Then, it creates a pretend database, which is just a list of to-do items in the computer's memory.  In a real app, this would be a real database that saves the data.

It also creates templates for what a to-do item looks like:  It has a title, a description, and a checkbox for whether it's finished.  There are separate templates for adding a new item, changing an item, or replacing an item completely.

Then, it sets up the different things you can do with the to-do list:

GET /tasks/{task_id}: View a specific item.
POST /tasks: Add a new item (title and description required).
PATCH /tasks/{task_id}: Change part of an item.
PUT /tasks/{task_id}: Replace an entire item.
DELETE /tasks/{task_id}: Remove an item.


Reuirements.txt, It tells your computer which extra tools (called "packages") it needs to make the project work.  When you run a special command, it goes and gets all those tools in the correct versions.  Some of the important tools are:

fastapi: The main tool for making the website part of your project.
pydantic: A tool for making sure the data you use is organized correctly.
uvicorn: A tool for running the website.
typing_extensions: A helper tool for older computers.
The file also lists a bunch of other tools that the main tools need to work.